import logo from "./logo.svg";
import "./App.css";
import Comps from "./component/Comps";

function App() {
  return (
    <div className="App">
      <Comps />
    </div>
  );
}

export default App;
