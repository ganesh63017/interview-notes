import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  constructor(private http: HttpService, private route: Router) {}

  testName: any;

  ngOnInit(): void {
    this.http.get('').subscribe({
      next: (res) => {
        this.testName = res;
        this.testName = this.testName.tests;
        console.log(this.testName);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  gotoTest(testType: any) {
    // console.log(testType);
    this.http.setTest(testType);
    this.route.navigate(['/test']);
  }
}
