import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  

  constructor(private activatedroute:ActivatedRoute,private route: Router) { }

  correct:any;
  wrong:any;
  total:any;
testName:any;
  ngOnInit(): void {
    this.activatedroute.queryParams.subscribe((data:any) => {
      console.log(data);
      this.correct = data.correct;
      this.wrong = data.wrong;
      this.total = data.totalQue;
      this.testName = data.testName;
  })
  }

  gotoHome(){
    this.route.navigate(['']);
  }

}
