import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root',
})
export class HttpService {
  constructor(private http: HttpClient) {}

  selectedTest: any;

  get(url: string) {
    return this.http.get(environment.baseUrl + url);
  }

  setTest(test: any) {
    localStorage.setItem('testName', test);
    this.selectedTest = test;
  }

  getTest() {
    this.selectedTest = localStorage.getItem('testName');
    return this.selectedTest;
  }
}
