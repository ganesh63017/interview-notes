import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
})
export class TestComponent implements OnInit {
  constructor(private http: HttpService, private fb: FormBuilder,
    private route: Router) { }
  getTestName: any;
  testList: any;

  currentQueNum: any = 0;
  Exam: any;
  Questions: any;


  checkedOptArray: any = [];
  radioOpt: any;

  ansArray: any = [];

  checkFlag = false;

  setDataInLocal: any = [];

  ngOnInit(): void {

    this.getTestName = this.http.getTest();

    this.http.get('').subscribe({
      next: (res) => {
        this.testList = res;
        this.testList = this.testList.tests;
        this.Exam = this.testList.find((x: any) => x.name === this.getTestName);

        this.Questions = this.Exam?.questions;
        this.Questions?.forEach((obj: any) => {
          obj.isHidden = true;
        });
        this.Questions[0]!.isHidden = false;
        console.log(this.Questions);
      },
      error: (err) => {
        console.log(err);
      },
    });


  }



  nextQuestion() {

    if (this.checkedOptArray.length > 0) {
      this.ansArray.push(this.checkedOptArray);

      // console.log(this.Questions[this.currentQueNum]._id);

      let obj = {
        qID: this.Questions[this.currentQueNum]._id,
        opt: this.checkedOptArray,
        ans: this.Questions[this.currentQueNum].correctOptionIndex,
        allQue: this.Questions[this.currentQueNum]
      }
      this.setDataInLocal.push(obj);
      // console.log('checkbox local storage',obj);

    } else if (this.radioOpt != null) {
      // console.log(this.Questions[this.currentQueNum]._id);
      this.ansArray.push(this.radioOpt);
      let obj = {
        qID: this.Questions[this.currentQueNum]._id,
        opt: this.radioOpt,
        ans: this.Questions[this.currentQueNum].correctOptionIndex,
        allQue: this.Questions[this.currentQueNum]
      }
      this.setDataInLocal.push(obj);
      // console.log('radio local storage',obj);     

    }
    console.log("final array", this.ansArray);

    if (this.currentQueNum < this.Questions.length - 1) {
      this.Questions[this.currentQueNum].isHidden = true;
      this.currentQueNum += 1;
      this.Questions[this.currentQueNum]
        ? (this.Questions[this.currentQueNum].isHidden = false)
        : false;
    } else {
      console.log('last que');
    }

    this.checkedOptArray = [];
    this.radioOpt = 0;

  }

  preQuestion() {
    this.ansArray.pop();
    // console.log(this.ansArray);  

    if (
      this.currentQueNum > 0 &&
      this.currentQueNum <= this.Questions.length - 1
    ) {
      this.Questions[this.currentQueNum].isHidden = true;
      this.currentQueNum -= 1;
      this.Questions[this.currentQueNum]
        ? (this.Questions[this.currentQueNum].isHidden = false)
        : false;
    } else {
      console.log('first que');
    }
  }

  onItemChange(e: any, optIndex: any) {
    console.log(" radio is : ", optIndex);
    this.radioOpt = optIndex;
  }


  checkboxValue(e: any, optIndex: any) {

    // console.log(e.target.checked);

    if (e.target.checked) {
      this.checkedOptArray.push(optIndex);

    } else {
      this.checkedOptArray.forEach((item: any) => {
        if (item == optIndex) {
          const index: any = this.checkedOptArray?.indexOf(item);
          this.checkedOptArray?.splice(index, 1);
          return;
        }
      });
    }

    // console.log(" array : ", this.checkedOptArray);
  }

  cntCorrect = 0;
  cntWrong = 0;
  gotoResult() {
    if (this.ansArray.length === this.Questions.length) {
      localStorage.setItem('Exam', JSON.stringify(this.setDataInLocal));
      console.log('stored');
    } else {
      console.log('not stored', this.ansArray.length);
    }

    let getLocalData = localStorage.getItem('Exam');

    let data = JSON.parse(getLocalData || '')

    console.log(data);
    data.forEach((element: any) => {

      if (element.allQue.type) {
        if (element.ans.length === element.opt.length) {
          let option = element.opt.sort();
          if (JSON.stringify(option) === JSON.stringify(element.ans)) {
            this.cntCorrect += 1;
          } else {
            this.cntWrong += 1;
          }
        }else{
          this.cntWrong += 1;
        }

      } else {
        if (element.ans === element.opt) {
          this.cntCorrect += 1;
        } else {
          this.cntWrong += 1;
        }
      }


    });

    console.log('correct opt', this.cntCorrect);

    console.log('wrong opt', this.cntWrong);

    let sendObj = {
      correct:this.cntCorrect,
      wrong:this.cntWrong,
      totalQue:this.Questions.length,
      testName:this.getTestName
    }

    localStorage.clear();
    this.route.navigate(['/result'],{queryParams: sendObj});

  }

}
